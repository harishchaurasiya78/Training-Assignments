export class Book {
      id!: number;
  title!: string;
  price!: number;
  publicationDate!: string; 
  description!: string;
  discountPercent!: number; 
}
