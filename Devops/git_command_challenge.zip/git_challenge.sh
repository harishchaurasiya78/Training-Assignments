#!/bin/bash

# Git Command Challenge Script
# Usage: ./git_challenge.sh <repository-url>

# Exit on error
set -e

REPO_URL=$1

if [ -z "$REPO_URL" ]; then
  echo "Usage: ./git_challenge.sh <repository-url>"
  exit 1
fi

# 1. Clone the repository
git clone $REPO_URL repo
cd repo

# 2. Create and switch to new branch feature/add-username
git checkout -b feature/add-username

# 3. Create username.txt file
echo "amanraj" > username.txt

# 4. Stage changes
git add username.txt

# 5. Commit changes
git commit -m "Add username file"

# 6. Push the branch
git push -u origin feature/add-username

# 7. Switch back to main
git checkout main

# 8. Create and switch to feature/update-readme
git checkout -b feature/update-readme

# 9. Update README.md
echo "This repository is for Git Command Challenge" >> README.md

# 10. Stage changes
git add README.md

# 11. Commit changes
git commit -m "Update README"

# 12. Push the branch
git push -u origin feature/update-readme

# 13. Switch back to main
git checkout main

# 14. Merge feature/update-readme into main
git merge feature/update-readme

# 15. Push the changes
git push origin main

echo "✅ Git Command Challenge Completed Successfully!"
