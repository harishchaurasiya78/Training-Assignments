# Git Command Challenge

## Description
This script automates the Git Command Challenge tasks step by step.

## Requirements
- Git must be installed and configured on your system.
- Access to the target repository (with push permissions).

## Usage
Run the script with the repository URL as argument:
```bash
./git_challenge.sh <repository-url>
```

## Steps Performed
1. Clone the repository
2. Create branch `feature/add-username`, add `username.txt`, commit & push
3. Create branch `feature/update-readme`, update `README.md`, commit & push
4. Merge `feature/update-readme` into `main` and push

## Example
```bash
./git_challenge.sh https://github.com/user/repo.git
```

