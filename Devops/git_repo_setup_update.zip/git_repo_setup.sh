#!/bin/bash

# Exit on error
set -e

# Variables (customize as needed)
PROJECT_NAME="my-project"
REMOTE_URL=$1  # Pass remote repo URL as first argument
MAIN_BRANCH="main"
FEATURE_BRANCH="feature-update"
COMMIT_MESSAGE="Initial project setup"
UPDATE_MESSAGE="Updated project code"

if [ -z "$REMOTE_URL" ]; then
  echo "Usage: ./git_repo_setup.sh <remote-repo-url>"
  exit 1
fi

# 1. Create a new project folder and initialize repo
mkdir $PROJECT_NAME
cd $PROJECT_NAME
git init

# Add a sample file
echo "# $PROJECT_NAME" > README.md
git add README.md
git commit -m "$COMMIT_MESSAGE"
echo "✅ Initial commit created."

# 2. Add remote and push to remote repository
git branch -M $MAIN_BRANCH
git remote add origin $REMOTE_URL
git push -u origin $MAIN_BRANCH
echo "✅ Pushed initial commit to remote."

# 3. Update code by pulling latest changes
git pull origin $MAIN_BRANCH
echo "✅ Pulled latest changes from remote."

# 4. Make changes and commit
echo "This is an update to the project." >> README.md
git add README.md
git commit -m "$UPDATE_MESSAGE"
git push origin $MAIN_BRANCH
echo "✅ Updated project code pushed to remote."

# 5. Create a separate branch and push
git checkout -b $FEATURE_BRANCH
echo "Feature branch changes." >> feature.txt
git add feature.txt
git commit -m "Added feature branch changes"
git push -u origin $FEATURE_BRANCH
echo "✅ Feature branch created and pushed."

# 6. Merge feature branch into main
git checkout $MAIN_BRANCH
git pull origin $MAIN_BRANCH
git merge $FEATURE_BRANCH
git push origin $MAIN_BRANCH
echo "✅ Feature branch merged into main branch."

echo "🎉 Git Repository Creation & Update Process Completed!"
