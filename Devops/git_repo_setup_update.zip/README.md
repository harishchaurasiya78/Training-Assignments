# Git Repository Setup & Update

## Description
This script automates the process of creating and updating a Git repository with the following steps:
- Create a new repository with initial commit
- Add a remote and push code
- Pull latest changes
- Make changes and commit
- Create a separate branch and push
- Merge feature branch into main

## Requirements
- Git installed and configured on your system.
- Access to the target repository (with push permissions).

## Usage
Run the script with the repository URL as argument:
```bash
./git_repo_setup.sh <remote-repo-url>
```

## Steps Performed
1. Create a new repository with initial commit
2. Add remote and push to repository
3. Pull latest changes
4. Make changes and push
5. Create and push a feature branch
6. Merge the feature branch into main

## Example
```bash
./git_repo_setup.sh https://github.com/user/repo.git
```

