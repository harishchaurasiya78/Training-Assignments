# Git Project Manager

## Description
This script automates the process of managing a Git repository with the following steps:
- Clone a repository
- List all branches
- Create and switch to a new branch
- Make changes to a file
- Commit and push changes
- Merge into main branch
- Pull latest changes

## Requirements
- Git installed and configured on your system.
- Access to the target repository (with push permissions).

## Usage
Run the script with the repository URL as argument:
```bash
./git_project_manager.sh <repository-url>
```

## Steps Performed
1. Clone the repository
2. List all branches
3. Create branch `feature-branch`
4. Switch to the branch
5. Update `README.md` file
6. Commit and push changes
7. Merge into `main` branch
8. Push and pull the latest changes

## Example
```bash
./git_project_manager.sh https://github.com/user/repo.git
```

