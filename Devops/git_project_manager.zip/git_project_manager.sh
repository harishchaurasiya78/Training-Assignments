#!/bin/bash

# Exit on error
set -e

# Variables
REPO_URL=$1         # First argument: repository URL
NEW_BRANCH="feature-branch"
FILE_TO_EDIT="README.md"
COMMIT_MESSAGE="Updated project file"
MAIN_BRANCH="main"  # Change to "master" if your repo uses master

if [ -z "$REPO_URL" ]; then
  echo "Usage: ./git_project_manager.sh <repository-url>"
  exit 1
fi

# 1. Clone repository
git clone "$REPO_URL" repo
cd repo

# 2. List all branches
echo "📌 Listing all branches:"
git branch -a

# 3. Create a new branch
git checkout -b $NEW_BRANCH
echo "✅ Created and switched to branch: $NEW_BRANCH"

# 4. Switch to a specific branch (here using NEW_BRANCH)
git checkout $NEW_BRANCH
echo "✅ Switched to branch: $NEW_BRANCH"

# 5. Make changes to a file
echo "This is an auto-update for Git Project Manager Challenge." >> $FILE_TO_EDIT

# 6. Stage and commit changes
git add $FILE_TO_EDIT
git commit -m "$COMMIT_MESSAGE"
echo "✅ Changes committed with message: '$COMMIT_MESSAGE'"

# 7. Push branch to remote
git push -u origin $NEW_BRANCH
echo "✅ Branch pushed to remote"

# 8. Switch back to main and merge
git checkout $MAIN_BRANCH
git pull origin $MAIN_BRANCH   # ensure latest
git merge $NEW_BRANCH
echo "✅ Merged branch '$NEW_BRANCH' into '$MAIN_BRANCH'"

# 9. Push merged changes
git push origin $MAIN_BRANCH
echo "✅ Main branch updated on remote"

# 10. Pull latest changes
git pull origin $MAIN_BRANCH
echo "✅ Pulled latest changes"

echo "🎉 Git Project Management Process Completed!"
