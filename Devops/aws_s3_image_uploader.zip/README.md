# AWS S3 Image Uploader

## Description
This is a simple Python-based AWS S3 image uploader. It allows users to upload images to an S3 bucket and generates a public URL for accessing the uploaded image.

## Requirements
- Python 3.x
- AWS account and credentials configured (`aws configure`)
- boto3 library

## Installation
1. Clone this repository or extract the zip file.
2. Navigate to the project folder.
3. Install required dependencies:
   ```bash
   pip install boto3
   ```

## Running the Application
Run the script using:
```bash
python main.py
```
You will be prompted to enter:
- **S3 bucket name**
- **Path to the image file**

## Example
```
Enter the S3 bucket name: my-image-bucket
Enter the path to the image file: ./test_image.png
```
Output:
```
Image uploaded successfully!
Public URL: https://my-image-bucket.s3.us-east-1.amazonaws.com/images/123e4567-e89b-12d3-a456-426614174000_test_image.png
```

## Considerations
- Ensure your AWS credentials are configured (`aws configure`).
- The bucket must exist and allow public read access for uploaded files.
- Unique keys are generated using UUID to prevent overwriting existing files.
- For production, avoid using `public-read` ACL directly. Instead, configure proper bucket policies or signed URLs.
