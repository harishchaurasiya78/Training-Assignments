import boto3
import os
import uuid

def upload_image_to_s3(bucket_name, file_path):
    try:
        s3 = boto3.client('s3')
        
        # Generate a unique key using UUID
        file_key = f"images/{uuid.uuid4()}_{os.path.basename(file_path)}"

        # Upload image with public-read ACL
        s3.upload_file(file_path, bucket_name, file_key, ExtraArgs={'ACL': 'public-read'})
        
        # Generate public URL
        region = s3.meta.region_name
        public_url = f"https://{bucket_name}.s3.{region}.amazonaws.com/{file_key}"
        
        print(f"Image uploaded successfully!")
        print(f"Public URL: {public_url}")
    
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    bucket_name = input("Enter the S3 bucket name: ")
    file_path = input("Enter the path to the image file: ")

    if not os.path.isfile(file_path):
        print("Error: The specified file does not exist.")
    else:
        upload_image_to_s3(bucket_name, file_path)
